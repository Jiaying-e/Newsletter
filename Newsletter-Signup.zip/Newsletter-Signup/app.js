 const express = require("express");
 const bodyParser = require("body-parser");
 const request = require("request");

 const app = express();

app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended: true}));

 app.get("/", function(req, res){

   res.sendFile(__dirname + "/signup.html");

 })

 app.post("/", function(req, res) {
   const firstName = req.body.fName;
   const lastName = req.body.lName;
   const email = req.body.email;

   const data = {
     members: [{
       email_address: email,
       status: "subscribed",
       merge_fields: {

         FNAME: firstName,
         LNAME: lastName

       }
     }]
   };

   const jsonData = JSON.stringify(data);
 });

 app.listen(3000, function(){
   console.log("SERVER IS RUNNING ON PORT 3000");
 })

// 1a2270c6616077e09d04bd6292b4b943-us7

//list id 353e349c71
